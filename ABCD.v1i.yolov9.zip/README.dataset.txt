# ABCD > 2024-06-18 8:34am
https://universe.roboflow.com/anmol-agrawal-/abcd-jcaa5

Provided by a Roboflow user
License: CC BY 4.0

